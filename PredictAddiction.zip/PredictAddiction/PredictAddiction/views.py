from django.shortcuts import render

def index(request):
    return render(request, 'templates/maps.html')

def resources(request):
    return render(request, 'templates/resources.html' )

def home(request):
    return render(request, 'templates/home.html')