from django import forms
from django.core.exceptions import ValidationError


class AssessmentForm(forms.Form):
    age = forms.IntegerField()
    #gender 
    g =[("1", "Male"), ("2", "Female"),('-9','Other')]
    gender = forms.ChoiceField(choices=g, label="Gender")   
    #Age
    a = [("2","12-14"),("3","15-17"),("4","18-20"),("5","21-24"),("6","25-29"),("7","30-34"),("8","35-39"),("9","40-44"),("10","45-59"),("11","50-54"),("12","55 AND OVER")]
    age = forms.ChoiceField(choices=a, label="Age")


    #Marital Status
    m = [("1","NEVER MARRIED"),("2","NOW MARRIED"),("3","SEPARATED"),("4","DIVORCED, WIDOWED"),("-9","OTHER")]
    martal = forms.ChoiceField(choices=m, label="Marital Status")   
    #Race
    r=[("1","ALASKA NATIVE [ALEUT, ESKIMO, INDIAN]"),("2","AMERICAN INDIAN [OTHER THAN ALASKA NATIVE]"),("3","ASIAN OR PACIFIC ISLANDER"),("4","BLACK OR AFRICAN AMERICAN"),("5","WHITE"),("13","ASIAN"),("20","OTHER SINGLE RACE"),("21","TWO OR MORE RACES"),("23","NATIVE HAWAIIAN OR OTHER PACIFIC ISLANDER"),('-9','OTHER')]
    race = forms.ChoiceField(choices=r, label="Race")

    #Education
    e = [("1","8 YEARS OR LESS"),("2","9-11"),("3","12"),("4","13-15"),("5","'16 OR MORE"),("-9","OTHER")]
    edu = forms.ChoiceField(choices=e, label="Education")   

    #Employment
    em = [("1","FULL TIME"),("2","PART TIME"),("3","UNEMPLOYED"),("4","NOT IN LABOR FORCE"),("-9","OTHER")]
    employment = forms.ChoiceField(choices=em, label="Employment")

    #Veteran Status
    vet = [("1", "Yes"), ("2", "No"),("-9","OTHER")]
    veter = forms.ChoiceField(choices=vet, label="Veteran")   

    #Living Arrangement
    la = [("1","HOMELESS"),("2","DEPENDENT LIVING"),("3","INDEPENDENT LIVING"),("-9","OTHER")]
    living = forms.ChoiceField(choices=la, label="Living Arrangement")   

    #Income Source
    i_s=[("1","WAGES/SALARY"),("2","PUBLIC ASSISTANCE"),("3","RETIREMENT/PENSION, DISABILITY"),("20","OTHER"),("21","NONE"),("-9","SKIP")]
    income = forms.ChoiceField(choices=i_s, label="Income Source")

    a_s = [("0","None"),("1","Once"),("2","2 OR MORE TIEMs"),("-9","OTHER")]
    arrest = forms.ChoiceField(choices=a_s, label="Arrests")
    #State
    st = [("1"," Alabama"),
    ("2"," Alaska"),
    ("3"," Arizona"),
    ("5"," Arkansas"),
    ("6"," California"),
    ("8"," Colorado"),
    ("9"," Connecticut"),
    ("10"," Delaware"),
    ("11"," District of Columbia"),
    ("12"," Florida"),
    ("13"," Georgia"),
    ("15"," Hawaii"),
    ("16"," Idaho"),
    ("17"," Illinois"),
    ("18"," Indiana"),
    ("19"," Iowa"),
    ("20"," Kansas"),
    ("21"," Kentucky"),
    ("22"," Louisiana"),
    ("23"," Maine"),
    ("24"," Maryland"),
    ("25"," Massachusetts"),
    ("26"," Michigan"),
    ("27"," Minnesota"),
    ("28"," Mississippi"),
    ("29"," Missouri"),
    ("30"," Montana"),
    ("31"," Nebraska"),
    ("32"," Nevada"),
    ("33"," New Hampshire"),
    ("34"," New Jersey"),
    ("35"," New Mexico"),
    ("36"," New York"),
    ("37"," North Carolina"),
    ("38","  North Dakota"),
    ("39"," Ohio"),
    ("40"," Oklahoma"),
    ("41"," Oregon"),
    ("42"," Pennsylvania"),
    ("44"," Rhode Island"),
    ("46"," South Dakota"),
    ("47"," Tennessee"),
    ("48"," Texas"),
    ("49"," Utah"),
    ("50"," Vermont"),
    ("51"," Virginia"),
    ("53"," Washington"),
    ("54"," West Virginia"),
    ("55"," Wisconsin"),
    ("56"," Wyoming"),
    ("72"," Puerto Rico")]   

    state = forms.ChoiceField(choices=st, label="State")   
        