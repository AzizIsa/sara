from django.core.files.storage import FileSystemStorage
from django.db import models

# Create your models here.

class Assessment(models.Model):
    assessment_name = models.CharField(max_length=200)
    def __str__(self):
        return self.assessment_name