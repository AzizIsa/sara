from django.urls import path
from .views import AssessmentView
#from . import views

urlpatterns = [
    path('', AssessmentView.as_view()),
]