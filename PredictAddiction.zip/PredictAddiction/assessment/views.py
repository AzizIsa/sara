from django.shortcuts import render
from .forms import AssessmentForm
from django.views.generic import TemplateView
from .models import Assessment


class AssessmentView(TemplateView):
   template = 'assessment/results.html'
   def get(self, request):
        
        form = AssessmentForm
        return render(request, 'assessment/index.html', {'form':form})
   
   def post(self,request):
      form = AssessmentForm(request.POST)
      if form.is_valid():
         af = form.cleaned_data
         age = int(af['age'])
         gender= int(af['gender'])
         race = int(af['race'])
         martal= int(af['martal'])
         edu= int(af['edu'])
         employment= int(af['employment'])
         veter= int(af['veter'])
         living= int(af['living'])
         income= int(af['income'])
         arrest= int(af['arrest'])
         state= int(af['state'])
         
         y= 1.56150511+0.002953*race-0.063668*age-0.013248*martal-0.019354*edu-0.110677*employment-0.022588*veter+0.030937*living-0.014229*income-0.000146*gender+0.213574*arrest-0.110677*2
         result = round(y * 100)
         return render(request, self.template, {'result':result})

          
        

         # y= intercept+0.002953*race-0.063668*age-0.013248*martal-0.019354*edu-0.022588*veter+0.030937*living-0.014229*income-0.000146*gender+0.213574*arrest-0.110677*2
        