from django.apps import AppConfig


class PhysiciansConfig(AppConfig):
    name = 'physicians'
